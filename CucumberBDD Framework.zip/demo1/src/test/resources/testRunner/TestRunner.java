package testRunner;


import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Search.class)
@testRunner(
   //path of feature file
   features = "demo1/src/test/resources/Feature",
    glue = {"stepdef"},
   )

public class TestRunner
{

}
