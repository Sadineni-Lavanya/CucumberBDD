package stepdef;

import com.javapointers.selenium.SeleniumUtil;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.*;
 
import java.net.URISyntaxException;
 
public class SearchStepDef {
 
    private WebDriver driver;
 
    @When("I go to {string}")
    public void iGoTo(String url) throws URISyntaxException {
      driver=new ChromeDriver();
       driver.get(url);
    }
    @And("Click on search box {string}")
    public void clickOnSearchBox(String searchQuery) {
    driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys(searchQuery)
    	
    }
 
   @And("Click on search icon")
    public void clickOnSearchIcon() {
        driver.findElement(By.xpath("//input[@type='submit']")).click();
    }
    @Then("I should be shown the results from my query")
    public void iShouldBeShownTheResultsFromMyQuery() {
        try {
            driver.findElement(By.xpath("//span[contains(text(),'Mobiles')]"));
        } catch (NoSuchElementException e) {
            throw new AssertionError("Result Page not displayed");
        }
        @And("Select the product")
        public void selectTheProduct() {
            driver.findElement(By.xpath("//span[contains(text(),'Additional Exchange Offers')]")).click();
            ArrayList<String> newTb = new ArrayList<String>(driver.getWindowHandles());
            driver.switchTo().window(newTb.get(1));
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("window.scrollBy(0,350)");
    }
        @And("Add it to the cart")
        public void addItToTheCart() {
        	driver.findElement(By.xpath("//input[@value='Add to Cart']")).click();
        }
            
    }
 }
   
	
	
	
	
	
	
	
	
	
	
	
	